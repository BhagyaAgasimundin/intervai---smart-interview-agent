
export interface InterviewConfig {
  jobTitle: string;
  jobDescription: string;
  candidateName: string;
  interviewType: 'technical' | 'behavioral' | 'general';
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface EvaluationResult {
  overallScore: number;
  competencies: {
    name: string;
    score: number;
    feedback: string;
  }[];
  strengths: string[];
  areasForImprovement: string[];
  summary: string;
  verdict: 'Hire' | 'Consider' | 'No Hire';
}

export enum AppState {
  SETUP,
  INTERVIEWING,
  EVALUATING,
  REPORT
}
