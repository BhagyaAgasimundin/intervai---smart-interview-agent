
import React, { useState } from 'react';
import { InterviewSetup } from './components/InterviewSetup';
import { InterviewSession } from './components/InterviewSession';
import { FeedbackReport } from './components/FeedbackReport';
import { InterviewConfig, EvaluationResult, AppState } from './types';
import { InterviewAgent } from './services/geminiService';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.SETUP);
  const [config, setConfig] = useState<InterviewConfig | null>(null);
  const [report, setReport] = useState<EvaluationResult | null>(null);
  const [loadingMsg, setLoadingMsg] = useState<string>('');

  const handleStartInterview = (conf: InterviewConfig) => {
    setConfig(conf);
    setAppState(AppState.INTERVIEWING);
  };

  const handleFinishInterview = async (agent: InterviewAgent) => {
    setAppState(AppState.EVALUATING);
    setLoadingMsg("Our AI is carefully reviewing the transcript...");
    
    try {
      const evaluation = await agent.evaluateInterview();
      setReport(evaluation);
      setAppState(AppState.REPORT);
    } catch (error) {
      console.error("Evaluation failed:", error);
      alert("Something went wrong during evaluation. Please try again.");
      setAppState(AppState.INTERVIEWING);
    }
  };

  const reset = () => {
    setAppState(AppState.SETUP);
    setConfig(null);
    setReport(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-indigo-100 selection:text-indigo-900">
      {/* Navigation Bar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={reset}>
            <div className="bg-indigo-600 p-2 rounded-lg">
              <i className="fas fa-microphone-lines text-white text-xl"></i>
            </div>
            <span className="text-xl font-black tracking-tight text-slate-900">IntervAI</span>
          </div>
          <div className="hidden md:flex items-center space-x-6">
            <a href="#" className="text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">How it works</a>
            <a href="#" className="text-sm font-medium text-slate-500 hover:text-indigo-600 transition-colors">Pricing</a>
            <button className="bg-slate-900 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-indigo-600 transition-colors">
              Sign Up
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {appState === AppState.SETUP && (
          <div className="space-y-12">
            <div className="text-center space-y-4 max-w-3xl mx-auto">
              <h1 className="text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Hire Smarter with <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">AI-Powered Interviews</span>
              </h1>
              <p className="text-xl text-slate-500 font-medium">
                The world's most advanced AI agent to screen, interview, and evaluate candidates instantly.
              </p>
            </div>
            <InterviewSetup onStart={handleStartInterview} />
          </div>
        )}

        {appState === AppState.INTERVIEWING && config && (
          <div className="space-y-6">
             <div className="flex items-center justify-center space-x-4 mb-4">
              <div className="flex items-center space-x-2 bg-indigo-50 text-indigo-700 px-4 py-2 rounded-full text-sm font-bold border border-indigo-100">
                <span className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse"></span>
                <span>Live Interview Mode</span>
              </div>
            </div>
            <InterviewSession config={config} onFinish={handleFinishInterview} />
          </div>
        )}

        {appState === AppState.EVALUATING && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8">
            <div className="relative">
              <div className="w-24 h-24 border-4 border-slate-200 border-t-indigo-600 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <i className="fas fa-brain text-2xl text-indigo-600 animate-pulse"></i>
              </div>
            </div>
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold text-slate-800">Generating Performance Report</h2>
              <p className="text-slate-500 max-w-xs">{loadingMsg}</p>
            </div>
          </div>
        )}

        {appState === AppState.REPORT && report && config && (
          <FeedbackReport result={report} config={config} onRestart={reset} />
        )}
      </main>

      <footer className="mt-auto py-12 border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-4">
          <div className="flex items-center justify-center space-x-2 opacity-50">
            <i className="fas fa-shield-halved"></i>
            <span className="text-xs font-bold uppercase tracking-[0.3em]">Built for Secure Recruiting</span>
          </div>
          <p className="text-slate-400 text-sm">© 2025 IntervAI Inc. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
