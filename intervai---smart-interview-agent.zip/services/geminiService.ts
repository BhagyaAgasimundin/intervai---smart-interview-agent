
import { GoogleGenAI, Type, Chat, GenerateContentResponse } from "@google/genai";
import { InterviewConfig, Message, EvaluationResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export class InterviewAgent {
  private chat: Chat | null = null;
  private history: Message[] = [];

  constructor(private config: InterviewConfig) {}

  async startInterview(): Promise<string> {
    this.chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: `You are an expert HR interviewer conducting a ${this.config.interviewType} interview for the position of "${this.config.jobTitle}".
        The job description is: "${this.config.jobDescription}".
        The candidate's name is "${this.config.candidateName}".
        
        Your Goal:
        1. Start by welcoming the candidate.
        2. Ask one question at a time.
        3. Listen to their responses and ask relevant follow-up questions if their answer is vague.
        4. Cover technical skills, problem-solving, and culture fit as appropriate for the role.
        5. Keep the conversation professional yet engaging.
        6. After about 5-7 questions, or when you feel you have enough information, politely conclude the interview and inform them that the evaluation is being prepared.
        
        Important: DO NOT provide the evaluation during the chat. Just conduct the interview.`,
      },
    });

    const response = await this.chat.sendMessage({ message: "Please start the interview." });
    const initialText = response.text || "Hello! I'm your interviewer today. Let's get started.";
    this.history.push({ role: 'model', text: initialText, timestamp: Date.now() });
    return initialText;
  }

  async sendResponse(userText: string): Promise<string> {
    if (!this.chat) throw new Error("Chat session not initialized");
    
    this.history.push({ role: 'user', text: userText, timestamp: Date.now() });
    const response = await this.chat.sendMessage({ message: userText });
    const modelText = response.text || "I see. Let's move to the next topic.";
    this.history.push({ role: 'model', text: modelText, timestamp: Date.now() });
    
    return modelText;
  }

  getHistory(): Message[] {
    return this.history;
  }

  async evaluateInterview(): Promise<EvaluationResult> {
    const transcript = this.history
      .map(m => `${m.role === 'user' ? 'Candidate' : 'Interviewer'}: ${m.text}`)
      .join('\n\n');

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Evaluate the following interview transcript for the role of ${this.config.jobTitle}.
      Job Description: ${this.config.jobDescription}
      
      Transcript:
      ${transcript}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallScore: { type: Type.NUMBER, description: "Score from 0 to 100" },
            competencies: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  score: { type: Type.NUMBER },
                  feedback: { type: Type.STRING }
                },
                required: ["name", "score", "feedback"]
              }
            },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            areasForImprovement: { type: Type.ARRAY, items: { type: Type.STRING } },
            summary: { type: Type.STRING },
            verdict: { type: Type.STRING, enum: ["Hire", "Consider", "No Hire"] }
          },
          required: ["overallScore", "competencies", "strengths", "areasForImprovement", "summary", "verdict"]
        }
      }
    });

    return JSON.parse(response.text.trim());
  }
}
