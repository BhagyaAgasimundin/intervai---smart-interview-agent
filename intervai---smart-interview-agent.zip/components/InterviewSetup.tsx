
import React, { useState } from 'react';
import { InterviewConfig } from '../types';

interface Props {
  onStart: (config: InterviewConfig) => void;
}

export const InterviewSetup: React.FC<Props> = ({ onStart }) => {
  const [config, setConfig] = useState<InterviewConfig>({
    jobTitle: '',
    jobDescription: '',
    candidateName: '',
    interviewType: 'technical',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (config.jobTitle && config.jobDescription && config.candidateName) {
      onStart(config);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200">
      <div className="bg-indigo-600 p-8 text-white">
        <h2 className="text-3xl font-bold mb-2">Configure Your Interview</h2>
        <p className="text-indigo-100">Provide role details to generate tailored interview questions.</p>
      </div>
      
      <form onSubmit={handleSubmit} className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-slate-700">Candidate Name</label>
            <input
              type="text"
              required
              className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              placeholder="e.g. John Doe"
              value={config.candidateName}
              onChange={(e) => setConfig({ ...config, candidateName: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm font-semibold text-slate-700">Interview Focus</label>
            <select
              className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              value={config.interviewType}
              onChange={(e) => setConfig({ ...config, interviewType: e.target.value as any })}
            >
              <option value="technical">Technical Focus</option>
              <option value="behavioral">Behavioral Focus</option>
              <option value="general">General Screening</option>
            </select>
          </div>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-slate-700">Job Title</label>
          <input
            type="text"
            required
            className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            placeholder="e.g. Senior Frontend Engineer"
            value={config.jobTitle}
            onChange={(e) => setConfig({ ...config, jobTitle: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-semibold text-slate-700">Job Description / Requirements</label>
          <textarea
            required
            rows={5}
            className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            placeholder="Paste the job description here..."
            value={config.jobDescription}
            onChange={(e) => setConfig({ ...config, jobDescription: e.target.value })}
          />
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2 shadow-lg hover:shadow-indigo-200"
        >
          <span>Start AI Interview</span>
          <i className="fas fa-arrow-right"></i>
        </button>
      </form>
    </div>
  );
};
