
import React from 'react';
import { EvaluationResult, InterviewConfig } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

interface Props {
  result: EvaluationResult;
  config: InterviewConfig;
  onRestart: () => void;
}

export const FeedbackReport: React.FC<Props> = ({ result, config, onRestart }) => {
  const chartData = result.competencies.map(c => ({
    subject: c.name,
    score: c.score,
    fullMark: 100,
  }));

  const getVerdictColor = (verdict: string) => {
    switch (verdict) {
      case 'Hire': return 'bg-green-100 text-green-700 border-green-200';
      case 'Consider': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'No Hire': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return '#10b981';
    if (score >= 60) return '#f59e0b';
    return '#ef4444';
  };

  return (
    <div className="max-w-5xl mx-auto pb-20 space-y-8 animate-fadeIn">
      {/* Summary Header */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="p-8 md:flex items-center justify-between gap-8 border-b border-slate-100">
          <div className="space-y-2">
            <h1 className="text-4xl font-black text-slate-900">Evaluation Report</h1>
            <p className="text-slate-500 text-lg">Candidate: <span className="font-bold text-indigo-600">{config.candidateName}</span> for <span className="font-bold">{config.jobTitle}</span></p>
          </div>
          <div className="mt-6 md:mt-0 flex flex-col items-center justify-center p-6 bg-slate-50 rounded-2xl border border-slate-200 min-w-[180px]">
            <span className="text-slate-500 uppercase text-[10px] font-bold tracking-[0.2em] mb-1">Overall Score</span>
            <div className={`text-6xl font-black mb-2`} style={{ color: getScoreColor(result.overallScore) }}>
              {result.overallScore}%
            </div>
            {/* Fix: Changed closing tag from </div> to </span> to resolve JSX parsing error that caused "Cannot find name 'div'" on later lines */}
            <span className={`px-4 py-1 rounded-full text-sm font-bold border ${getVerdictColor(result.verdict)}`}>
              {result.verdict}
            </span>
          </div>
        </div>

        <div className="p-8 grid md:grid-cols-2 gap-12">
          {/* Chart Section */}
          <div className="space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center space-x-2">
              <i className="fas fa-chart-pie text-indigo-500"></i>
              <span>Competency Breakdown</span>
            </h3>
            <div className="h-[300px] w-full bg-slate-50 rounded-xl p-4 border border-slate-100">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ left: 20 }}>
                  <XAxis type="number" domain={[0, 100]} hide />
                  <YAxis type="category" dataKey="subject" width={100} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="score" radius={[0, 4, 4, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getScoreColor(entry.score)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* AI Summary */}
          <div className="space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center space-x-2">
              <i className="fas fa-robot text-indigo-500"></i>
              <span>AI Executive Summary</span>
            </h3>
            <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed bg-indigo-50/50 p-6 rounded-xl border border-indigo-100 italic">
              "{result.summary}"
            </div>
          </div>
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid md:grid-cols-3 gap-8">
        {/* Strengths */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200">
          <h4 className="font-bold text-green-600 mb-4 flex items-center space-x-2">
            <i className="fas fa-check-circle"></i>
            <span>Key Strengths</span>
          </h4>
          <ul className="space-y-3">
            {result.strengths.map((s, idx) => (
              <li key={idx} className="flex items-start space-x-3 text-sm text-slate-700">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 shrink-0"></span>
                <span>{s}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Improvement Areas */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200">
          <h4 className="font-bold text-red-600 mb-4 flex items-center space-x-2">
            <i className="fas fa-exclamation-triangle"></i>
            <span>Improvement Areas</span>
          </h4>
          <ul className="space-y-3">
            {result.areasForImprovement.map((a, idx) => (
              <li key={idx} className="flex items-start space-x-3 text-sm text-slate-700">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0"></span>
                <span>{a}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Specific Feedback */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-slate-200">
          <h4 className="font-bold text-indigo-600 mb-4 flex items-center space-x-2">
            <i className="fas fa-comment-dots"></i>
            <span>Competency Insights</span>
          </h4>
          <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
            {result.competencies.map((c, idx) => (
              <div key={idx} className="border-b border-slate-100 last:border-0 pb-3 mb-3">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-xs uppercase text-slate-400">{c.name}</span>
                  <span className="text-xs font-bold text-slate-800">{c.score}/100</span>
                </div>
                <p className="text-xs text-slate-600">{c.feedback}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        <button
          onClick={onRestart}
          className="bg-slate-900 hover:bg-black text-white px-10 py-4 rounded-xl font-bold transition-all flex items-center space-x-3 shadow-xl hover:-translate-y-1 active:scale-95"
        >
          <i className="fas fa-redo"></i>
          <span>Conduct Another Interview</span>
        </button>
      </div>
    </div>
  );
};
