
import React, { useState, useEffect, useRef } from 'react';
import { Message, InterviewConfig } from '../types';
import { InterviewAgent } from '../services/geminiService';

interface Props {
  config: InterviewConfig;
  onFinish: (agent: InterviewAgent) => void;
}

export const InterviewSession: React.FC<Props> = ({ config, onFinish }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const agentRef = useRef<InterviewAgent | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const start = async () => {
      const agent = new InterviewAgent(config);
      agentRef.current = agent;
      setIsTyping(true);
      const initialText = await agent.startInterview();
      setMessages(agent.getHistory());
      setIsTyping(false);
    };
    start();
  }, [config]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isTyping || !agentRef.current) return;

    const userText = inputValue;
    setInputValue('');
    
    // Optimistically update UI
    const tempMessages = [...messages, { role: 'user', text: userText, timestamp: Date.now() } as Message];
    setMessages(tempMessages);
    
    setIsTyping(true);
    try {
      await agentRef.current.sendResponse(userText);
      setMessages([...agentRef.current.getHistory()]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsTyping(false);
    }
  };

  const isInterviewConcluding = messages.some(m => 
    m.role === 'model' && 
    (m.text.toLowerCase().includes("conclude") || 
     m.text.toLowerCase().includes("thank you for your time") ||
     m.text.toLowerCase().includes("evaluation is being prepared"))
  );

  return (
    <div className="max-w-4xl mx-auto flex flex-col h-[80vh] bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-indigo-500 rounded-full flex items-center justify-center">
            <i className="fas fa-robot text-xl"></i>
          </div>
          <div>
            <h3 className="font-bold">{config.jobTitle} Interview</h3>
            <p className="text-xs text-slate-400">Live Session with IntervAI</p>
          </div>
        </div>
        <button 
          onClick={() => agentRef.current && onFinish(agentRef.current)}
          className="text-sm bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white px-4 py-2 rounded-lg border border-red-500/20 transition-all font-medium"
        >
          End & Evaluate Early
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50">
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl px-5 py-3 shadow-sm ${
              m.role === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none' 
                : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
            }`}>
              <p className="whitespace-pre-wrap leading-relaxed text-sm md:text-base">{m.text}</p>
              <span className={`text-[10px] mt-1 block ${m.role === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                {new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none px-5 py-3 shadow-sm">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-200"></div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer / Input */}
      <div className="p-6 bg-white border-t border-slate-200">
        {isInterviewConcluding ? (
          <div className="text-center space-y-3">
            <p className="text-slate-600 font-medium">The interview session has concluded.</p>
            <button
              onClick={() => agentRef.current && onFinish(agentRef.current)}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-8 rounded-xl transition-all shadow-lg shadow-indigo-200 flex items-center justify-center space-x-2 mx-auto"
            >
              <i className="fas fa-file-contract"></i>
              <span>Generate Full Evaluation Report</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleSend} className="relative">
            <textarea
              rows={2}
              className="w-full px-5 py-4 pr-24 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all resize-none shadow-inner bg-slate-50"
              placeholder="Type your response here..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend(e);
                }
              }}
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className={`absolute right-3 top-1/2 -translate-y-1/2 p-3 rounded-xl transition-all ${
                !inputValue.trim() || isTyping 
                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100'
              }`}
            >
              <i className="fas fa-paper-plane text-xl"></i>
            </button>
          </form>
        )}
        <p className="text-[10px] text-slate-400 mt-3 text-center uppercase tracking-widest font-semibold">
          AI Interviewer Session Active • Data is encrypted
        </p>
      </div>
    </div>
  );
};
